# ------------------ Marketing.py ------------------------------#
# Desc: Classes that hold marketing targets data
# Dev: Cheng Liu
# Date: 9/10/2018
# ChangeLog: (When, Who, What)
# --------------------------------------------------------------#

import Customers
if __name__ == "__main__":
    raise Exception ("Marketing.py should NOT run by itself")

# ------ Make chile class -------- #
class MarketingTarget(Customers.Customer):
    """Class for Marketing targets data"""
    # --------------------------------------------------------------#
    # Desc: Classes that hold marketing targets data
    # Dev: Cheng Liu
    # Date: 9/10/2018
    # ChangeLog: (When, Who, What)
    # --------------------------------------------------------------#

    # --- Fields --- #
    # Id = Customer Id

    # --- Constructor --- #
    def __init__(self, Id = ""):
        # Attributes
        self.__Id = Id

    # --- Properties --- #
    # Id
    @property #getter(accessor)
    def Id(self):
        return self.__Id

    @Id.setter #(mutator)
    def Id(self, Value):
        self.__Id = Value

    # --- Methods --- #
    def ToString(self):
        """Explicitly returns the field data"""
        strData = super().ToString()
        return str(self.Id) + ',' + strData

    def __str__(self):
        """Implicitly returns field data"""
        return self.ToString()

# ---------- End of MarketingTarget Class------------ #

class MarketingTargetList(object):
    """ Static class for holding a list of marketing targets data"""
    # --------------------------------------------------------------#
    # Desc: Manages a list of marketing target customers data
    # Dev: Cheng Liu
    # Date: 9/10/2018
    # ChangeLog: (When, Who, What)
    # --------------------------------------------------------------#

    # --- Fields --- #
    __lstCustomers = [] # a private list with Customer objects

    # --- Constructor --- #
    #@staticmethod in python constructors cannot be static
    # def __init__():
        # Attributes

    # -- Properties -- #
        # None

    # --- Methods --- #
    @staticmethod
    def AddTarget(target):
        # print(target.__class__) # for testing
        if (str(target.__class__) == "<class 'Marketing.MarketingTarget'>"):
            MarketingTargetList.__lstCustomers.append(target)
            print("New customers added as marketing campaign targets!") # for testing
        else:
            raise Exception("Only Marketing Targeted Customers can be added to this list")

    @staticmethod
    def ToString(): # This overrides the original method (it's polymorphic)
        """Explicitly returns field data"""
        strData = "Id, FirstName, LastName\n"
        for item in MarketingTargetList.__lstCustomers:
            strData += str(item.Id) + "," + item.FirstName + "," + item.LastName + "\n"
            return strData

    @staticmethod
    def __str__(): # This overrides the original method
        """Implicitly returns field data"""
        strData = MarketingTargetList.ToString()
        return strData

# --------------- End of Class ---------------------- #
