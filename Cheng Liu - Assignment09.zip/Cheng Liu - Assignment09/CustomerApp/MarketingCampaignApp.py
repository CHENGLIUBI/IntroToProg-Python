# ------------------ MarketingCampaignApp.py------------------------------#
# Desc: An application that manages data of new Customers for Marketing target campaigns
# Dev: Cheng Liu
# Date: 9/10/2018
# ChangeLog: (When, Who, What)
# --------------------------------------------------------------#

if __name__ == "__main__":
    import DataProcessor, Marketing
else:
    raise Exception("CustomerApp.py was not created to be imported")

# --- Data --- #
# declare variables and constants
objC = None # an Customer object
intId = 0 # an Customer ID
gIntLastId = 0 # records the last Customer ID used in the client
strFirstName = "" # an Customer's first name
strLastName = "" # an Customer's last name
strInput = "" # temporary user input

# --- Processing --- #
# perform tasks
def ProcessNewCustomerData(Id, FirstName, LastName):
    try:
        # Create Customer Object
        objC = Marketing.MarketingTarget()
        objC.Id = Id
        objC.FirstName = FirstName
        objC.LastName = LastName
        Marketing.MarketingTargetList.AddTarget(objC)
    except Exception as e:
        print(e)

def SaveDataToFile():
    try:
        objF = DataProcessor.File()
        objF.FileName = "New_Marketing_Targets.txt"
        objF.TextData = Marketing.MarketingTargetList.ToString()
        print("Data was saved to " + objF.FileName)
        objF.SaveData()
    except Exception as e:
        print(e)

# --- Presentation (I/O) --- #
# __main__

# get user input
strUserInput = ""
while(True):
    strUserInput = input("Would you like to add new customer for marketing campaigns? (y/n)")
    if(strUserInput.lower() == "y"):
        # Get Customer ID from the user
        intId = int(input("Enter an Customer ID (Last Id was " + str(gIntLastId) + "): "))
        gIntLastId = intId

        # Get Customer's First name from the user
        strFirstName = str(input("Enter an Customer's First Name: "))

        # Get Customer's Last Name from the user
        strLastName = str(input("Enter an Customer's Last Name: "))

        # process input
        ProcessNewCustomerData(intId, strFirstName, strLastName)
    else:
        break

# Send program output
print("The Current Customers for marketing campaign is: ")
print("------------------------")
print(Marketing.MarketingTargetList.ToString())

# get user input
strInput = input("Would you like to save this data? (y/n)")
if(strInput == "y"):
    SaveDataToFile()
    # send program output
    print("Completed!")
else:
    print("Data was not saved.")

print("This application has ended. Thank you.")

