# ------------------- DataProcessor.py --------------------------#
# Desc: Classes that read and write data
# Dev: Cheng Liu
# Date: 09/10/2018
# ChangeLog: (When, Who, What)
# ---------------------------------------------------------------#

# --- Checking if the module is being ran directly --
if __name__ == "__main__":
    raise Exception ("DataProcessor.py should NOT run by itself")

class File(object):
    """ Process data using files"""
    # ----------------------------------------------------------#
    # Desc: Classes that read and write data
    # Dev: Cheng Liu
    # Date: 09/10/2018
    # ChangeLog: (When, Who, What)
    # ---------------------------------------------------------------#

    # -- Fields -- #
    # FileName = name of file
    # TextData = data read from and written to file

    # -- Constructor --
    def __init__(self,FileName = "Customer Data.txt", TextData = ""): # default FileName & TextData is none specified
        # Attributes
        self.FileName = FileName
        self.TextData = TextData

    # -- Properties -- #
    # FileName
    @property
    def FileName(self):
        return self.__FileName # private

    @FileName.setter
    def FileName(self, Value):
        self.__FileName = Value

    # TextData
    @property
    def TextData(self):
        return self.__TextData

    @TextData.setter
    def TextData(self, Value):
        self.__TextData = Value

    # -- Method -- #
    def SaveData(self):
        """Write Data"""
        try:
            objFile = open(self.FileName, "a")
            objFile.write(self.TextData)
            objFile.close()
        except Exception as e:
            print("SaveData() Error in DataProcessor.py: " + str(e))
        return self.TextData

    def GetData(self):
        """Read Data"""
        try:
            objFile = open(self.FileName,"r")
            self.TextData = objFile.read()
            objFile.close()
        except Exception as e:
            print("GetData() Error in DataProcessor.py: " + str(e))
        return self.TextData

    def ToString(self):
        """Explictly returns field data"""
        return self.FileName + "," + self.TextData

    def __str__(self):
        """Implicitly returns field data"""
        return self.FileName + "," + self.TextData

    def __str__(self):
        """Implicitly returns field data"""
        return self.ToString()

# ------------------- End of Class ------------------#

class Database(object):
    """ Process data using files"""
    # ----------------------------------------------------------#
    # Desc: Process data using a database
    # Dev: Cheng Liu
    # Date: 09/10/2018
    # ChangeLog: (When, Who, What)
    # ---------------------------------------------------------------#

    # --- Fields --- #
    # ConnectionString = code to connect to DB
    # TextData = data read from and written to DB

    # --- Constructor --- #
    def __init__(self, ConnectionString):
        # Attributes
        self.ConnectionString = ConnectionString
        raise Exception("Database Class is not ready yet!")
# ------------------- End of Class ------------------#
