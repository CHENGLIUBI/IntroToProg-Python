#-------------------------------------------------#
# Title: Assignment 05 - Manage a To Do List
# Dev:   Cheng Liu
# Date:  Aug 13th, 2018
# Desc: This assignment is to create a new program that manages a 'To do list.'
# ChangeLog: (Who, When, What)
# Cheng Liu, 8/13/2018, created new code
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFileName = an object that represents a file
# strData = a row of text data from the file
# dicRow = a row of data separated into elements of a dictionary {Task, Priority}
# dicTable = a dictionary that acts as a 'table' or rows
# strName = a menu of user options
# strChoice = capture the user option selection
# A text file (Todo.txt) was created with the following data:
# Clean House, Low
# Pay Bills, High
objFileName = "C:\_PythonClass\Cheng Liu - Assignment05\ToDo.txt"
strData=""
dicRow={}
dicTable=[]

#-- Processing --#
# Step 1
# Load each row of data from the ToDo.txt file into a Python dictionary.
objFile = open(objFileName,"r")
for row in objFile:
    strData = row
    dicRow = {"Task":(strData.split(",")[0]).strip(), "Priority":(strData.split(",")[1]).strip()}
    # Add the new dictionary "row" into a Python list object (now the data will be managed as a table).
    dicTable.append(dicRow)

#-- Presentation (I/O) --#
# Step 2
# Display the contents of the List to the user.
print("Exiting tasks: \n\r",dicTable)

# Step 3
# Allow the user to Add or Remove tasks from the list using numbered choices.
while (True):
    print ("""
    Menu of Options:
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]\n\r"))
    print()

    # 1) show current data
    if (strChoice.strip() =='1'):
        print("Current tasks: \n\r", dicTable)
    # 2) add a new item
    elif (strChoice.strip() =='2'):
        strAddTask = input("Enter a new Task: ")
        strAddPriority = input("Enter a Priority: ")
        dicRow = {"Task": strAddTask.strip(), "Priority": strAddPriority.strip()}
        dicTable.append(dicRow)
    # 3) remove an item
    elif (strChoice.strip() =='3'):
        strRemoveTask = input("Enter the Task to remove: ")
        dicTable.remove(strRemoveTask)
    # 4) save the data to file
    elif (strChoice.strip() == '4'):
        objFile = open(objFileName, "w")
        for row in dicTable:
            objFile.write(str(row))
        objFile.close()
        print("Tasks Saved!\n\r",dicTable)
    # 5) exit the program
    elif (strChoice.strip() == '5'):
        break
