#-------------------------------------------------#
# Title: Assignment 06 - Manage a To Do List
# Dev:   Cheng Liu
# Date:  Aug 13th, 2018
# Desc: This assignment is to create a new program that manages a 'To do list.'
# ChangeLog: (Who, When, What)
# Cheng Liu, 8/20/2018, created new code
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFileName = an object that represents a file
# strData = a row of text data from the file
# dicRow = a row of data separated into elements of a dictionary {Task, Priority}
# lstTable = a dictionary that acts as a 'table' or rows
# strMenu = a menu of user options
# strChoice = capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 3)
# User can see data (Step 2)
# User can insert or delete data(Step 2)
# User can save to file (Step 2)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# create a class with functions

# Step 3
# Display menu to users and call the functions according to the options selected

# ------------------------------------------------- #
objFileName = "C:\_PythonClass\Cheng Liu - Assignment06\ToDo.txt"
strData=""
dicRow={}
lstTable=[]

#-- Processing --#
# Step 1
# Load each row of data from the ToDo.txt file into a Python dictionary.
objFile = open(objFileName,"r")
for line in objFile:
    strData = line.split(",") # readline() reads a line of the data into 2 elements
    dicRow = {"Task":(strData[0]).strip(), "Priority":(strData[1]).strip()}
    # Add the new dictionary "row" into a Python list object (now the data will be managed as a table).
    lstTable.append(dicRow)
objFile.close()

# Step 2
# create a class to hold a list of functions
class MenuOption(object):
    # define the method
    @staticmethod
    def ShowItem (v1, v2):
        """This function shows the current item in the txt file"""
        print("******* Current tasks: \n")
        for row in lstTable:
            print (row[v1] + "(" + row[v2] + ")")
        print("*************************\n")

    @staticmethod
    def AddNewItem (v1,v2):
        """ This function adds new items to the table"""
        strAddTask = str(input("Enter a new Task: "))
        strAddPriority = str(input("Enter a Priority [high | low]: "))
        dicRow = {v1: strAddTask.strip(), v2: strAddPriority.strip()}
        lstTable.append(dicRow)
        print("Current Data in table:\n")
        for dicRow in lstTable:
            print(dicRow)

    @staticmethod
    def RemoveItem (strKeyToRemove):
        """ This function removes an item from the table"""
        strKeyToRemove = input("Enter the Task to remove: ")
        blnItemRemoved = False # creating a boolean flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): # the value function creates a list
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber +=1
        # end for loop

        # 5b  update user on the status
        if (blnItemRemoved == True):
            print ("The task was removed.")
        else:
            print("Task not found. ")

    @staticmethod
    def SaveData (v1, v2):
        """ This function save the data into the text file """
        print("******* Current tasks: \n")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"]+")")
        print("*************************\n")

        #6b ask if they want to save that data
        if("y" == str(input("Save the data to file? (y/n): ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved file! Pres the [Enter] key to return to menu.")
        else:
            input("New data was not saved. Press the [Enter] key to return to menu.")


# Step 3
# Allow the user to Add or Remove tasks from the list using numbered choices.
while (True):
    print ("""
    Menu of Options:
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]\n\r"))
    print() # adding a new line after the input

    # Show the current items in the table
    if (strChoice.strip() =='1'):
        MenuOption.ShowItem("Task","Priority")

    # Add a new item to the list/Table
    elif (strChoice.strip() =='2'):
        MenuOption.AddNewItem("Task", "Priority")
        MenuOption.ShowItem("Task", "Priority")
        continue # to show the menu

    # remove a item
    elif (strChoice.strip() =='3'):
        MenuOption.RemoveItem("Task")
        MenuOption.ShowItem("Task", "Priority")
        continue # to show the menu

    # Save tasks to the ToDo.txt file
    elif (strChoice.strip() == '4'):
        MenuOption.SaveData("Task", "Priority")
        MenuOption.ShowItem("Task", "Priority")
        continue # to show the menu

    # exit the program
    elif (strChoice.strip() == '5'):
        break
